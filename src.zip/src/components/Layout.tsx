import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, Outlet, useLocation, useSearchParams } from 'react-router-dom';
import { LogOut, User as UserIcon, Menu, X, Sun, Moon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../theme/ThemeProvider';
import Footer from './Footer';
import FeedbackWidget from './FeedbackWidget';
import { Toast } from './Toast';
import { Button, Badge } from './ui';
import { useMediaQuery } from '../hooks/useMediaQuery';
import { apiGet } from '../utils/jobApi';
import DesktopNav from './layout/DesktopNav';
import MobileDrawer from './layout/MobileDrawer';
import { ADMIN_LINKS, PUBLIC_LINKS } from './layout/navLinks';

export default function Layout() {
  const loc = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user, logout, isAuthenticated, isAdmin } = useAuth();
  const { mode, toggle } = useTheme();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerClosing, setDrawerClosing] = useState(false);
  const [unreadFeedback, setUnreadFeedback] = useState(0);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const isMobileNav = useMediaQuery('(max-width: 767px)');

  const hideFeedbackWidget = isAdmin || loc.pathname.startsWith('/admin');

  // ── Toast triggers from URL params ──────────────────────────────────────
  useEffect(() => {
    if (searchParams.get('unsubscribed') === 'true') {
      setToast({ message: 'You have been unsubscribed from the weekly digest.', type: 'success' });
      searchParams.delete('unsubscribed');
      setSearchParams(searchParams, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  const closeDrawer = useCallback(() => {
    setDrawerClosing(prev => {
      if (prev) return prev;
      setTimeout(() => {
        setDrawerOpen(false);
        setDrawerClosing(false);
      }, 200);
      return true;
    });
  }, []);

  // Close drawer on route change or breakpoint flip
  useEffect(() => { if (drawerOpen) closeDrawer(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [loc.pathname, isMobileNav]);

  // Lock body scroll while drawer open
  useEffect(() => {
    if (drawerOpen) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [drawerOpen]);

  // Poll feedback count for admins
  useEffect(() => {
    if (!isAdmin) return;
    apiGet<{ unread?: number }>('/api/feedback/stats')
      .then(data => setUnreadFeedback(data?.unread || 0))
      .catch(() => {});
  }, [isAdmin, loc.pathname]);

  const isActive = useCallback((path: string) => loc.pathname === path, [loc.pathname]);
  const links = useMemo(() => isAdmin ? ADMIN_LINKS : PUBLIC_LINKS, [isAdmin]);

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <nav
        className="nav-blur"
        style={{ position: 'sticky', top: 0, zIndex: 50, borderBottom: '1px solid var(--border)' }}
        aria-label="Main navigation"
      >
        <div
          style={{
            maxWidth: 1600,
            margin: '0 auto',
            padding: '0 clamp(16px, 3vw, 24px)',
            height: 60,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          {/* Logo */}
          <Link
            to={isAdmin ? '/dashboard' : '/'}
            style={{ display: 'flex', alignItems: 'center', gap: 9, textDecoration: 'none', flexShrink: 0 }}
            aria-label="English Jobs in Germany home"
          >
            <img
              src="/logo.jpeg"
              alt=""
              style={{ height: isMobileNav ? 28 : 32, width: 'auto', display: 'block', flexShrink: 0 }}
              loading="eager"
              decoding="async"
            />
            <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', lineHeight: 1, flexShrink: 0 }}>
              <span style={{ fontFamily: "'Playfair Display',serif", fontSize: isMobileNav ? '0.95rem' : '1.1rem', fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '-0.02em', whiteSpace: 'nowrap' }}>
                English <span style={{ color: 'var(--primary)' }}>Jobs</span>
              </span>
              {!isMobileNav && (
                <span style={{ fontSize: '0.55rem', color: 'var(--text-secondary)', letterSpacing: '0.15em', textTransform: 'uppercase', marginTop: 2 }}>in Germany</span>
              )}
              {isAdmin && (
                <span style={{ fontSize: '0.58rem', fontWeight: 700, background: 'var(--danger-soft)', color: 'var(--danger)', borderRadius: 4, padding: '1px 5px', letterSpacing: '0.05em', alignSelf: 'flex-start', marginTop: 2 }}>ADMIN</span>
              )}
            </div>
          </Link>

          {!isMobileNav && (
            <DesktopNav links={links} isActive={isActive} unreadFeedback={unreadFeedback} />
          )}

          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <button
              onClick={toggle}
              aria-label={`Switch to ${mode === 'dark' ? 'light' : 'dark'} mode`}
              className="no-touch-expand"
              style={{
                width: 34, height: 34, borderRadius: 8,
                border: '1px solid var(--border-mid)', background: 'transparent',
                cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--text-secondary)', transition: 'border-color 0.18s, color 0.18s',
              }}
            >
              {mode === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
            </button>

            {!isMobileNav && isAuthenticated && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <Link
                  to="/profile"
                  className="no-touch-expand"
                  style={{
                    fontSize: '0.8rem',
                    color: 'var(--text-muted)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    textDecoration: 'none',
                    padding: '6px 10px',
                    borderRadius: 8,
                    border: '1px solid transparent',
                    transition: 'color 0.18s, border-color 0.18s',
                    fontWeight: 600,
                  }}
                >
                  <UserIcon size={13} /> {user?.name}
                  {isAdmin && <Badge variant="red" style={{ fontSize: '0.58rem', padding: '2px 6px' }}>ADMIN</Badge>}
                </Link>
                <button
                  onClick={logout}
                  className="no-touch-expand"
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: '0.78rem', display: 'flex', alignItems: 'center', gap: 5, fontFamily: 'inherit', fontWeight: 600 }}
                >
                  <LogOut size={13} /> Logout
                </button>
              </div>
            )}
            {!isMobileNav && !isAuthenticated && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Link to="/login"><Button variant="ghost" size="sm">Log in</Button></Link>
                <Link to="/signup"><Button size="sm">Get alerts</Button></Link>
              </div>
            )}

            {isMobileNav && (
              <button
                onClick={() => (drawerOpen ? closeDrawer() : setDrawerOpen(true))}
                aria-label={drawerOpen ? 'Close menu' : 'Open menu'}
                aria-expanded={drawerOpen}
                aria-controls="mobile-nav-drawer"
                className="no-touch-expand"
                style={{
                  width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: 'none', border: '1px solid var(--border)', borderRadius: 8,
                  cursor: 'pointer', color: 'var(--text-primary)',
                }}
              >
                {drawerOpen ? <X size={18} /> : <Menu size={18} />}
              </button>
            )}
          </div>
        </div>
      </nav>

      <MobileDrawer
        open={drawerOpen}
        closing={drawerClosing}
        links={links}
        isActive={isActive}
        isAuthenticated={isAuthenticated}
        isAdmin={isAdmin}
        user={user}
        onClose={closeDrawer}
        onLogout={logout}
      />

      {toast && <Toast message={toast.message} type={toast.type} onDismiss={() => setToast(null)} />}

      <main style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }} role="main">
        <Outlet />
      </main>
      <Footer />
      {!hideFeedbackWidget && <FeedbackWidget />}
    </div>
  );
}
